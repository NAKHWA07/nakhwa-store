const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const STOCK_FILE = './stock.json';

function readStock() {
  if (!fs.existsSync(STOCK_FILE)) return {};
  return JSON.parse(fs.readFileSync(STOCK_FILE));
}

function writeStock(stock) {
  fs.writeFileSync(STOCK_FILE, JSON.stringify(stock, null, 2));
}

// الحصول على المخزون
app.get('/stock', (req, res) => {
  res.json(readStock());
});

// شراء منتج
app.post('/buy', (req, res) => {
  const { product, size } = req.body;
  let stock = readStock();

  if (!stock[product] || !stock[product][size] === undefined) {
    return res.status(400).json({ error: 'المنتج أو المقاس غير موجود' });
  }

  if (stock[product][size] <= 0) {
    return res.status(400).json({ error: 'نفذت الكمية' });
  }

  stock[product][size] -= 1;
  writeStock(stock);

  res.json({ success: true, stock: stock[product][size] });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});