let cart = JSON.parse(localStorage.getItem("cart")) || [];
const delivery = 8;
let selectedSize = null;
let selectedPrice = 0;

// تحديث السعر عند اختيار المقاس
document.querySelectorAll('.sizes button').forEach(btn => {
  btn.addEventListener('click', () => {
    btn.parentElement.querySelectorAll('button').forEach(b => b.style.border = 'none');
    btn.style.border = '2px solid #fff';
    selectedSize = btn.dataset.size;
    selectedPrice = parseInt(btn.dataset.price);
    const priceElement = btn.closest('.card').querySelector('.price');
    if(priceElement) priceElement.innerText = selectedPrice + " DT";
  });
});

// إضافة للسلة
function addToCart(name, size, price){
  if(!size) { alert("اختر مقاس!"); return; }
  cart.push({name, size, price});
  localStorage.setItem("cart", JSON.stringify(cart));
  alert("تمت الإضافة للسلة ✔");
}

// عرض السلة
function renderCart(){
  const items = document.getElementById("cartItems");
  if(!items) return;
  let html = "";
  let total = delivery;
  cart.forEach((p,index)=>{
    html += `<div class="card">
      <p>${p.name} (${p.size}) — ${p.price} DT</p>
      <button onclick="removeFromCart(${index})">إلغاء الشراء</button>
    </div>`;
    total += p.price;
  });
  items.innerHTML = html || "السلة فارغة";
  document.getElementById("total").innerText = total;
}

function removeFromCart(index){
  cart.splice(index,1);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

renderCart();

// ارسال الطلب مع emailjs (تأكد من استبدال المفاتيح)
if(document.getElementById("orderForm")){
  const orderForm = document.getElementById("orderForm");
  const phoneInput = document.getElementById("phone");
  const addressSelect = document.getElementById("address");

  orderForm.addEventListener('submit', function(e){
    e.preventDefault();
    const phone = phoneInput.value.trim();
    const tunisianPhoneRegex = /^[24579]\d{7}$/;
    if(!tunisianPhoneRegex.test(phone)){ alert("رقم الهاتف غير صحيح"); return; }
    if(!addressSelect.value){ alert("اختر ولاية"); return; }

    // إرسال عبر EmailJS
    emailjs.send("service_u1gdh3l","template_vc4oduf",{
      order: cart.map(p=>`${p.name} (${p.size}) - ${p.price} DT`).join("\n"),
      total: document.getElementById("total").innerText,
      name: document.getElementById("name").value,
      phone: phone,
      address: addressSelect.value
    }).then(()=>{
      localStorage.removeItem("cart");
      cart = [];
      document.querySelector(".cart").style.display = "none";
      document.querySelector(".order").style.display = "none";
      document.getElementById("thankYou").style.display = "block";
    }).catch(err=>{ alert("خطأ في الإرسال"); console.log(err); });
  });
}